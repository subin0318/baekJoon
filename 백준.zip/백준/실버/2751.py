# N개의 수가 주어졌을 때, 이를 오름차순으로 정렬하는 프로그램을 작성하시오.

# a=[5,4,3,2,1]

# a.sort()

# print(a)

# import sys

# a=int(sys.stdin.readline()) 
# b=[]

# for _ in range(a):
#     k=int(sys.stdin.readline())
#     b.append(k)

# sorted_a = sorted(b)
# print(*sorted_a)

# import sys

# a=int(sys.stdin.readline())
# b=[]

# for _ in range(a):
#     k=int(sys.stdin.readline())
#     b.append(k)

# b.sort()
# print(*b)