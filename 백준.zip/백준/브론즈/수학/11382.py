# A+B+C의 값을 출력한다.

a,b,c= map(int, input().split())
print(a+b+c)