# 첫 번째 줄에 LoveisKoreaUniversity를 공백으로 구분하여 N번 출력한다.

# a=int(input())
# print(a*"LoveisKoreaUniversity")

# LoveisKoreaUniversity LoveisKoreaUniversity

# a=["LoveisKoreaUniversity","LoveisKoreaUniversity"]

# print(*a)

a=int(input())
b=[]

for _ in range (a):
    b.append("LoveisKoreaUniversity")

print(*b)


