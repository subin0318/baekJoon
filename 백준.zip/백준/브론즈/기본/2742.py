#첫째 줄부터 N번째 줄 까지 차례대로 출력한다.

# 5    

# 5
# 4
# 3
# 2
# 1


a=int(input())

for i in range(a,0,-1):
    print(i)