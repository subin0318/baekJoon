# 문자열 대소문자 바꾸는 문제
string = input()
string = string.swapcase()
print(string)