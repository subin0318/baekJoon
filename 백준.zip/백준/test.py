import sys
a=sys.stdin.readline()
print(a)